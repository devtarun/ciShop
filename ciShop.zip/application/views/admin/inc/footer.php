            <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
            <!--End Back To Top Button-->
            <!--Start footer-->
            <footer class="footer">
                <div class="container">
                    <div class="text-center">
                        Copyright © 2018 DashRock Admin
                    </div>
                </div>
            </footer>
            <!--End footer-->
        </div>
        <!--End wrapper-->
        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.min.js"></script>
        <!-- simplebar js -->
        <script src="<?php echo base_url(); ?>assets/admin/plugins/simplebar/js/simplebar.js"></script>
        <!-- waves effect js -->
        <script src="<?php echo base_url(); ?>assets/admin/js/waves.js"></script>
        <!-- sidebar-menu js -->
        <script src="<?php echo base_url(); ?>assets/admin/js/sidebar-menu.js"></script>
        <!-- Custom scripts -->
        <script src="<?php echo base_url(); ?>assets/admin/js/app-script.js"></script>
        <!-- Vector map JavaScript -->
        <script src="<?php echo base_url(); ?>assets/admin/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- Sparkline JS -->
        <script src="<?php echo base_url(); ?>assets/admin/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
        <!-- Chart js -->
        <script src="<?php echo base_url(); ?>assets/admin/plugins/Chart.js/Chart.min.js"></script>
        <!--notification js -->
        <script src="<?php echo base_url(); ?>assets/admin/plugins/notifications/js/lobibox.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/plugins/notifications/js/notifications.min.js"></script>
        <!-- Index js -->
        <script src="<?php echo base_url(); ?>assets/admin/js/index.js"></script>
    </body>
</html>