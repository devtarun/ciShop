
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">checkout</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- page main wrapper start -->
<main>
    <!-- checkout main wrapper start -->
    <div class="checkout-page-wrapper pt-100 pb-90 pt-sm-58 pb-sm-54">
        <div class="container">
            <div class="row">
                <!-- Checkout Billing Details -->
                <div class="col-xs-12 text-center">
                    Thank you for shopping with us.
                </div>
            </div>
        </div>
    </div>
    <!-- checkout main wrapper end -->
</main>